from flask import Flask, render_template, request, send_file, send_from_directory, abort, redirect, url_for
import os

app = Flask(__name__)

# Set the upload folder where files will be stored
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Set the folder for static files to be served
STATIC_FOLDER = 'instructions'
app.config['STATIC_FOLDER'] = STATIC_FOLDER

# Define a list of allowed file extensions
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

# Function to check if the folder exists, if not, create it
def create_upload_folder():
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)

# Function to check if a file has an allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_page():
    create_upload_folder()
    if request.method == 'POST':
        if 'file' not in request.files:
            return "No file part"
        
        file = request.files['file']

        if file.filename == '':
            return "No selected file"
        
        #if file and allowed_file(file.filename):
        if file:
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            return redirect(url_for('upload_page'))  # Redirect to /upload after successful upload
        else:
            return "File type not allowed. Please upload a valid file."

    # List all uploaded files
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('upload.html', files=files)

@app.route('/download/<filename>')
def download_file(filename):
    create_upload_folder()
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    else:
        return "We have been giving proper instructions that you will try this, where it was mentioned what we will do about it. But the issue is we are not able to find the  instruction file, it's like it is hidding in the plain sight", 404

# Route to serve static files for download
@app.route('/instructions/<filename>')
def serve_static(filename):
    return send_from_directory(app.config['STATIC_FOLDER'], filename, as_attachment=True)

# Error handler for undefined paths (404 error)
@app.errorhandler(404)
def page_not_found(e):
    return "We don't want you to try directory traversal that's why we came you with such a dangerous message - Don't look", 404

if __name__ == '__main__':
    app.run(debug=True)

